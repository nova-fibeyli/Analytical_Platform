# Analytics Platform - Setup Guide

## Project Overview

This project is a simple **data analytics platform** that retrieves **time-series data** from **MongoDB** and visualizes it using **Chart.js**. It allows users to:

- **Filter data** by date range
- **Select specific fields** for analysis
- **View statistical metrics** such as average, min, max, and standard deviation

---

## Prerequisites

Before running the project, make sure you have the following installed:

1. **Node.js** (v16+ recommended) – [Download](https://nodejs.org/)
2. **MongoDB Community Edition** (Installed and running) – [Download](https://www.mongodb.com/try/download/community)
3. **A Web Browser** (Chrome, Firefox, Edge, etc.)

---

## Installation Steps

Follow these steps to set up and run the project:

### 1️⃣ Start MongoDB

Open a terminal and start the MongoDB server:

```sh
mongod --dbpath C:\data\db
```

> If the folder `C:\data\db` does not exist, create it manually:

```sh
mkdir C:\data\db
```

To check if MongoDB is running, open another terminal and run:

```sh
mongosh
```

Then type:

```js
show dbs
```

If MongoDB is working correctly, it should list available databases.

---

### 2️⃣ Import Sample Data

If the database is empty, import sample data:

```sh
mongosh
```

Then run:

```js
use analytics
db.measurements.insertMany([
  { timestamp: new Date("2025-01-01T12:00:00Z"), field1: 22.5, field2: 65, field3: 400 },
  { timestamp: new Date("2025-01-01T13:00:00Z"), field1: 23.1, field2: 67, field3: 420 },
  { timestamp: new Date("2025-01-01T14:00:00Z"), field1: 21.8, field2: 64, field3: 410 }
])
```

Then exit:

```sh
exit
```

---

### 3️⃣ Setup Backend

Navigate to the backend folder and install dependencies:

```sh
cd backend
npm install
```

---

### 4️⃣ Start Backend Server

Run the backend:

```sh
node index.js
```

If successful, you should see:

```
Server running on port 3000
```

---

### 5️⃣ Test API Endpoints

Open another terminal and try these:

✅ Fetch time-series data:

```sh
curl "http://localhost:3000/api/measurements?field=field1&start_date=2025-01-01&end_date=2025-01-02"
```

✅ Fetch statistical metrics:

```sh
curl "http://localhost:3000/api/measurements/metrics?field=field1"
```

If you see **"Cannot connect" errors**, make sure **MongoDB is running (`mongod`)** and **your backend server is started (`node index.js`)**.

---

### 6️⃣ Setup Frontend

Navigate to the frontend folder:

```sh
cd ../frontend
```

Simply open `index.html` in a browser:

- **Windows**: Double-click `index.html`
- **Linux/Mac**: Open it manually in Chrome/Firefox.

---

## Troubleshooting

### MongoDB Not Found?

Run:

```sh
where mongod
```

If not found, add its path to your system `PATH` variable.

### Port 3000 is already in use?

Find the process:

```sh
netstat -ano | findstr :3000
```

Kill it:

```sh
taskkill /PID <PROCESS_ID> /F
```

### npm install Fails?

Ensure **package.json** exists inside `backend/`. If missing, recreate it:

```sh
cd backend
npm init -y
```

---

## Conclusion

Now you have:
✅ A **running MongoDB database**  
✅ A **working backend API** on **port 3000**  
✅ A **frontend UI** displaying analytics

Your **Analytics Platform** is now fully set up! 🚀📊
