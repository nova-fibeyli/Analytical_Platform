const express = require("express");
const mongoose = require("mongoose");

const app = express();
app.use(express.json());

mongoose.connect("mongodb://localhost:27017/analytics", {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const measurementSchema = new mongoose.Schema({
  timestamp: Date,
  field1: Number,
  field2: Number,
  field3: Number,
});

const Measurement = mongoose.model("Measurement", measurementSchema);

app.get("/api/measurements", async (req, res) => {
  const { field, start_date, end_date } = req.query;

  if (!field || !start_date || !end_date) {
    return res.status(400).json({
      error: "Missing required parameters: field, start_date, end_date",
    });
  }

  if (isNaN(Date.parse(start_date)) || isNaN(Date.parse(end_date))) {
    return res.status(400).json({ error: "Invalid date format" });
  }

  try {
    const data = await Measurement.find({
      timestamp: { $gte: new Date(start_date), $lte: new Date(end_date) },
    }).select(`timestamp ${field}`);

    if (data.length === 0) {
      return res
        .status(404)
        .json({ error: "No data found in the specified range" });
    }

    res.json(data);
  } catch (err) {
    res.status(500).json({ error: "Error fetching data" });
  }
});

app.get("/api/measurements/metrics", async (req, res) => {
  const { field } = req.query;
  if (!field) return res.status(400).json({ error: "Missing field parameter" });

  try {
    const data = await Measurement.find().select(field);
    const values = data.map((item) => item[field]).filter((v) => v !== null);

    if (values.length === 0) {
      return res
        .status(404)
        .json({ error: "No data available for the requested field" });
    }

    const avg = values.reduce((a, b) => a + b, 0) / values.length;
    const min = Math.min(...values);
    const max = Math.max(...values);
    const stdDev = Math.sqrt(
      values.reduce((a, b) => a + Math.pow(b - avg, 2), 0) / values.length
    );

    res.json({ avg, min, max, stdDev });
  } catch (err) {
    res.status(500).json({ error: "Error calculating metrics" });
  }
});

app.listen(3000, () => console.log("Server running on port 3000"));
