
# Analytical Platform Using Node.js and MongoDB

## Description
This project implements an analytical platform to retrieve and visualize time-series data stored in a MongoDB database. It allows users to filter data by date range, select fields for analysis, and view metrics like average, minimum, maximum, and standard deviation.

## Features
- Time-series data filtering and visualization.
- RESTful API for fetching data and calculating metrics.
- Frontend with Chart.js for interactive data visualization.
- Improved error handling and sample dataset included.

## Installation

### Prerequisites
- Node.js
- MongoDB

### Steps
1. Clone the repository and navigate to the backend folder.
2. Install dependencies: `npm install`.
3. Import sample data into MongoDB:
   ```bash
   mongoimport --db analytics --collection measurements --file data/sample_data.json --jsonArray
   ```
4. Start the server: `node index.js`.
5. Open `frontend/index.html` in a browser to view the UI.

## Endpoints
### Fetch Time-Series Data
`GET /api/measurements?field=<field>&start_date=<YYYY-MM-DD>&end_date=<YYYY-MM-DD>`

### Fetch Metrics
`GET /api/measurements/metrics?field=<field>`
